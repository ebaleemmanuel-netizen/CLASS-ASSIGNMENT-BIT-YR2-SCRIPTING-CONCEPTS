<?php
// Class Activity 2: Fee Classification

$tuitionFee = 2000000;
$testValues = [0, 700000, 2000000, 2200000];

foreach ($testValues as $amountPaid) {
    $balance = $tuitionFee - $amountPaid;

    // Order matters: the most specific condition (fully paid) is checked first
    if ($amountPaid >= $tuitionFee) {
        $status = "Cleared";
    } elseif ($amountPaid > 0) {
        $status = "Partial payment";
    } else {
        $status = "No payment";
    }

    echo "Amount paid: " . number_format($amountPaid) . "\n";
    echo "Balance: " . number_format($balance) . "\n";
    echo "Status: " . $status . "\n\n";
}
?>
