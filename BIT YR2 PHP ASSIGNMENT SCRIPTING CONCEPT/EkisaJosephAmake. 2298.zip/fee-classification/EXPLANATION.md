# Class Activity 2: Fee Classification (PHP)

## How to run
- Terminal: `php feeClassification.php`
- Browser: `php -S localhost:8000`, then open http://localhost:8000/feeClassification.php

Assumed tuition fee: 2,000,000.

## Script summary
1. `$tuitionFee` holds the fee; `$amountPaid` is passed into `classifyFee()`.
2. `$balance = $tuitionFee - $amountPaid`.
3. An `if / elseif / else` chain assigns the status:
   - `$amountPaid >= $tuitionFee` -> Cleared
   - `$amountPaid > 0` -> Partial payment
   - otherwise -> No payment
4. The amount paid, balance and status are displayed (plain text in the terminal, a table in the browser).
5. Tested with 0, 700000, 2000000 and 2200000.

## Results

| Amount paid | Balance    | Status          |
|-------------|------------|-----------------|
| 0           | 2,000,000  | No payment      |
| 700,000     | 1,300,000  | Partial payment |
| 2,000,000   | 0          | Cleared         |
| 2,200,000   | -200,000   | Cleared         |

## Explanation of results
- **0:** Fails the first check (0 is not >= 2,000,000) and the second (0 is not > 0), so it falls to `else`: No payment. The full fee is still owed.
- **700,000:** Fails the first check but passes `$amountPaid > 0`: Partial payment, with 1,300,000 outstanding.
- **2,000,000:** Passes the first check because it equals the fee: Cleared, balance 0.
- **2,200,000:** Also passes the first check. The balance of -200,000 means the student overpaid by 200,000, which would be a credit or refund.

## How condition order affects the results
An `if / elseif / else` chain runs top to bottom and stops at the first true condition, so order matters. The conditions overlap: any amount >= 2,000,000 is also > 0.

If `$amountPaid > 0` were checked first, 2,000,000 and 2,200,000 would match it immediately and be labelled "Partial payment", which is wrong, and the "Cleared" branch would never run.

The most specific condition (fully paid) must come first, then the broader one (some payment), and `else` catches what is left (nothing paid).
