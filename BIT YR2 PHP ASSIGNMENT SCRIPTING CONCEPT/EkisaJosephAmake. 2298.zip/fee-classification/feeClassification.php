<?php
// Class Activity 2: Fee Classification
// Works in the terminal (php feeClassification.php) and in a browser
// (php -S localhost:8000, then open http://localhost:8000/feeClassification.php).

// 1. Variables: tuition fee and amount paid
$tuitionFee = 2000000;

// Classify one payment and return the amount paid, balance and status
function classifyFee($tuitionFee, $amountPaid)
{
    // 2. Calculate the balance
    $balance = $tuitionFee - $amountPaid;

    // 3. if / elseif / else (most specific condition first)
    if ($amountPaid >= $tuitionFee) {
        $status = "Cleared";
    } elseif ($amountPaid > 0) {
        $status = "Partial payment";
    } else {
        $status = "No payment";
    }

    return ["paid" => $amountPaid, "balance" => $balance, "status" => $status];
}

// 5. Test values
$testValues = [0, 700000, 2000000, 2200000];

// In the browser, also accept a custom amount from the form
if (PHP_SAPI !== 'cli' && isset($_GET['amount']) && is_numeric($_GET['amount'])) {
    $testValues = [(float) $_GET['amount']];
}

$results = [];
foreach ($testValues as $paid) {
    $results[] = classifyFee($tuitionFee, $paid);
}

// 4. Display amount paid, balance and status
if (PHP_SAPI === 'cli') {
    foreach ($results as $r) {
        echo "Amount paid: {$r['paid']}\n";
        echo "Balance: {$r['balance']}\n";
        echo "Status: {$r['status']}\n";
        echo "---\n";
    }
    return;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Fee Classification</title>
<style>
  body { font-family: sans-serif; max-width: 640px; margin: 2rem auto; padding: 0 1rem; }
  table { border-collapse: collapse; width: 100%; margin-top: 1rem; }
  th, td { border: 1px solid #ccc; padding: 8px; text-align: right; }
  th:last-child, td:last-child { text-align: left; }
  th { background: #f2f2f2; }
</style>
</head>
<body>
<h1>Fee Classification</h1>
<p>Tuition fee: <strong><?= number_format($tuitionFee) ?></strong></p>

<form method="get">
  <label>Amount paid:
    <input type="number" name="amount" step="any" required>
  </label>
  <button type="submit">Classify</button>
  <a href="?">Run default tests</a>
</form>

<table>
  <tr><th>Amount paid</th><th>Balance</th><th>Status</th></tr>
  <?php foreach ($results as $r): ?>
  <tr>
    <td><?= number_format($r['paid']) ?></td>
    <td><?= number_format($r['balance']) ?></td>
    <td><?= htmlspecialchars($r['status']) ?></td>
  </tr>
  <?php endforeach; ?>
</table>
</body>
</html>
