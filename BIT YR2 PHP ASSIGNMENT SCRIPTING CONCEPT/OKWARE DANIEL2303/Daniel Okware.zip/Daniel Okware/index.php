<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Fee Classification</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: gray;
            padding: 40px;
        }

        .container {
            width: 450px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 0 10px gray;
        }

        h2 {
            text-align: center;
        }

        label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            box-sizing: border-box;
        }

        button {
            width: 100%;
            padding: 12px;
            margin-top: 20px;
            background-color: blue;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }

        .result {
            margin-top: 20px;
            padding: 15px;
            background-color: antiquewhite;
            border-radius: 5px;
        }
    </style>
</head>

<body>

<div class="container">

    <h2>Fee Classification</h2>

    <form method="POST">

        <label>Tuition Fee (UGX)</label>
        <input type="number" name="tuition_fee" value="200000" required>

        <label>Amount Paid (UGX)</label>
        <input type="number" name="amount_paid" min="0" required>

        <button type="submit">Check Fee Status</button>

    </form>

    <?php

    if ($_SERVER["REQUEST_METHOD"] == "POST") {

        // Create variables
        $tuitionFee = $_POST["tuition_fee"];
        $amountPaid = $_POST["amount_paid"];

        // Calculate balance
        $balance = $tuitionFee - $amountPaid;

        // Classify payment
        if ($amountPaid == 0) {

            $status = "No payment";

        } elseif ($amountPaid < $tuitionFee) {

            $status = "Partial payment";

        } else {

            $status = "Cleared";
        }

        // Display results
        echo "<div class='result'>";

        echo "<strong>Tuition Fee:</strong> UGX " . number_format($tuitionFee) . "<br>";

        echo "<strong>Amount Paid:</strong> UGX " . number_format($amountPaid) . "<br>";

        echo "<strong>Balance:</strong> UGX " . number_format($balance) . "<br>";

        echo "<strong>Status:</strong> " . $status;

        echo "</div>";
    }

    ?>

</div>

</body>
</html>
