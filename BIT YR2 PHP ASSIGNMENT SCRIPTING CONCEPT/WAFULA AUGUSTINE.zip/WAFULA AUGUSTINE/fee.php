<?php
// Class Activity 2: Fee Classification

// 1. Create variables for tuition fee and amount paid
$tuitionFee = 2000000;

// Test values given by lecturer: 0, 700000, 2000000, 2200000
$testAmounts = [0, 700000, 2000000, 2200000];

echo "<h3>Fee Classification Test Results</h3>";
echo "Tuition Fee: UGX $tuitionFee <hr>";

foreach ($testAmounts as $amountPaid) {
    
    // 2. Calculate the balance
    $balance = $tuitionFee - $amountPaid;
    if ($balance < 0) {
        $balance = 0; // If overpaid, balance is 0
    }

    // 3. Use if, elseif, and else to assign status
    if ($amountPaid >= $tuitionFee) {
        $status = "Cleared";
    } elseif ($amountPaid > 0) {
        $status = "Partial payment";
    } else {
        $status = "No payment";
    }

    // 4. Display the amount paid, balance, and status
    echo "Amount Paid: UGX $amountPaid | ";
    echo "Balance: UGX $balance | ";
    echo "Status: <b>$status</b><br>";
}

echo "<hr>";

// Optional: Form version for manual testing
if (isset($_POST['paid'])) {
    $amountPaid = (int)$_POST['paid'];
    $balance = $tuitionFee - $amountPaid;
    if ($balance < 0) $balance = 0;

    if ($amountPaid >= $tuitionFee) {
        $status = "Cleared";
    } elseif ($amountPaid > 0) {
        $status = "Partial payment";
    } else {
        $status = "No payment";
    }

    echo "<h4>Your Check:</h4>";
    echo "Amount Paid: UGX $amountPaid <br>";
    echo "Balance: UGX $balance <br>";
    echo "Status: <b>$status</b>";
}
?>

<!-- Simple form to test yourself -->
<form method="POST">
    <br>
    <input type="number" name="paid" placeholder="Enter amount paid" required>
    <button type="submit">Check Fee Status</button>
</form>

<br><hr>
<h4>5. Explain how the condition order affects the results:</h4>
<p>
<b>Correct Order is: Cleared (>=2000000) -> Partial (>0) -> No payment (else)</b><br><br>
If you put <code>if ($amountPaid > 0)</code> FIRST, then even 2,200,000 will be called "Partial payment" because 2,200,000 is also > 0. The program stops at the first true condition.<br><br>
So you MUST check the biggest condition first. If you check No payment first, all results will be wrong.
</p>
